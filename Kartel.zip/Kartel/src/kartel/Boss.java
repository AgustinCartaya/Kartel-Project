/**
 * Classe qui modelisse les boss
 * 
 * classe parent: Jeton
 */
package kartel;

/**
 *
 * @author
 */
public class Boss extends Jeton{
    

    
    //true si le boss est prisoner
    private boolean prisoner; 

    // Constructeur
    /**
     * 
     * @param gang 
     */
    public Boss(Gang gang){
        super(gang, "boss");
        this.prisoner = false;
    }

    // Getters et Setters 

    public boolean isPrisoner() {
        return prisoner;
    }
    
    public void setPrisoner(boolean prision) {
        this.prisoner = prision;
    }
    
    
    //Override méthodes 
    
    @Override
    public String toString() {
        return  '[' + getGang().getAbb()+ ']';
    }

}
